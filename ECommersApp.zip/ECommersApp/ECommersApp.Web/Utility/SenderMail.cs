﻿using Microsoft.AspNetCore.Identity.UI.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;

namespace ECommersApp.Web.Utility
{
    public class SenderMail:IEmailSender
    {
        public Task SendEmailAsync(string email, string subject, string htmlMessage)
        {
            return SendMail(email, subject, htmlMessage);
        }
        public Task SendMail(string email, string subject, string body)
        {
            MailMessage mail = new MailMessage();
            mail.To.Add(email);
            mail.From = new MailAddress("nileshcs344@gmail.com");
            mail.Subject = "Verify Your Account";
            //string Body = $"Your OTP is <b> {Otp}</b>  <br/>thanks for choosing us.";
            mail.Body = body;
            mail.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new System.Net.NetworkCredential("nileshcs344@gmail.com", "password"); // Enter seders User name and password  
            smtp.EnableSsl = true;
            smtp.Send(mail);
            return Task.CompletedTask;
        }
    }

}
