﻿using ECommersApp.Web.Data;
using ECommersApp.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ECommersApp.Web.Controllers
{

    [Authorize(Roles = WC.AdminRole)]
    public class ApplicationTypeController : Controller
    {
        private readonly ApplicationDbContext _dbContext;
        public ApplicationTypeController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        [HttpGet]
        public IActionResult Index()
        {
            IEnumerable<ApplicationType> model = _dbContext.ApplicationTypes;
            return View(model);
        }

        
        //Get Create
        public IActionResult Create()
        {
            return View();
        }

        //POST Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(ApplicationType model)
        {
            if (ModelState.IsValid)
            {
                _dbContext.ApplicationTypes.Add(model);
                _dbContext.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(model);
        }

        //Get Edit
        public IActionResult Edit(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            var model = _dbContext.ApplicationTypes.Find(id);
            if (model == null)
            {
                return NotFound();
            }
            return View(model);
        }

        //POST Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(ApplicationType model)
        {
            if (ModelState.IsValid)
            {
                _dbContext.ApplicationTypes.Update(model);
                _dbContext.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(model);
        }

        //Get Delete
        public IActionResult Delete(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            var model = _dbContext.ApplicationTypes.Find(id);
            if (model == null)
            {
                return NotFound();
            }
            return View(model);
        }

        //POST Delete
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeletePost(int? id)
        {
            var model = _dbContext.ApplicationTypes.Find(id);
            if (model == null)
            {
                return NotFound();
            }
            _dbContext.ApplicationTypes.Remove(model);
            _dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}

